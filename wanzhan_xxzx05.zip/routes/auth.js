const express = require('express');
const { check } = require('express-validator');
const authController = require('../controllers/authController');

const router = express.Router();

// 用户注册
router.post(
  '/register',
  [
    check('username').not().isEmpty(),
    check('password').isLength({ min: 6 })
  ],
  authController.register
);

// 用户登录
router.post(
  '/login',
  [
    check('username').not().isEmpty(),
    check('password').exists()
  ],
  authController.login
);

module.exports = router;
