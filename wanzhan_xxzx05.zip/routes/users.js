const express = require('express');
const { check } = require('express-validator');
const userController = require('../controllers/userController');
const authMiddleware = require('../middleware/auth');

const router = express.Router();

// 获取当前用户信息
router.get('/me', authMiddleware, userController.getCurrentUser);

// 更新用户信息
router.put(
  '/me',
  authMiddleware,
  [
    check('username').optional().not().isEmpty(),
    check('password').optional().isLength({ min: 6 })
  ],
  userController.updateUser
);

module.exports = router;
