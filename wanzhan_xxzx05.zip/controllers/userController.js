const User = require('../models/User');

// 获取当前用户信息
const getCurrentUser = async (req, res) => {
  try {
    const user = await User.findById(req.user.userId)
      .select('-password -__v');
    if (!user) {
      return res.status(404).json({ message: '用户不存在' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 更新用户信息
const updateUser = async (req, res) => {
  try {
    const { username, password } = req.body;
    const updates = {};

    if (username) {
      // 检查用户名是否已存在
      const existingUser = await User.findOne({ username });
      if (existingUser && existingUser._id.toString() !== req.user.userId) {
        return res.status(400).json({ message: '用户名已存在' });
      }
      updates.username = username;
    }

    if (password) {
      updates.password = password;
    }

    const updatedUser = await User.findByIdAndUpdate(
      req.user.userId,
      { $set: updates },
      { new: true }
    ).select('-password -__v');

    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getCurrentUser, updateUser };
